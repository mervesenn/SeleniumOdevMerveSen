package org.example.page;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.example.methods.Methods;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.List;
import java.util.Random;

public class ProductPage {
    Random rand = new Random();
    Methods methods;
    Logger logger = LogManager.getLogger(ProductPage.class);
    public ProductPage(){
        methods = new Methods();
    }
    public void selectProduct() {
        methods.sendKeys(By.id("search-input"), "oyuncak");
        methods.waitBySeconds(3);
        methods.click(By.cssSelector(".common-sprite.button-search"));
        methods.waitBySeconds(3);
        methods.click(By.cssSelector("#faceted-search-group-6 > div.faceted-search-group-name.mg-b-10 > span")); //7.ürüne elle click yapıldı
        methods.waitBySeconds(3);
        methods.click(By.xpath("//div[@class='product-list']//div[@class='product-cr'][5]//i[@class='fa fa-heart']"));
        methods.waitBySeconds(1);
        methods.click(By.xpath("//div[@class='product-list']//div[@class='product-cr'][6]//i[@class='fa fa-heart']"));
        methods.waitBySeconds(1);
        methods.click(By.xpath("//div[@class='product-list']//div[@class='product-cr'][7]//i[@class='fa fa-heart']"));
        methods.waitBySeconds(1);
        methods.click(By.xpath("//div[@class='product-list']//div[@class='product-cr'][8]//i[@class='fa fa-heart']"));
        methods.waitBySeconds(1);

        Assert.assertTrue(methods.isElementVisible(By.xpath("//div[@class='product-list']//div[@class='product-cr'][5]//i[@class='fa fa-heart red']")));
        methods.waitBySeconds(1);
        Assert.assertTrue(methods.isElementVisible(By.xpath("//div[@class='product-list']//div[@class='product-cr'][6]//i[@class='fa fa-heart red']")));
        methods.waitBySeconds(1);
        Assert.assertTrue(methods.isElementVisible(By.xpath("//div[@class='product-list']//div[@class='product-cr'][7]//i[@class='fa fa-heart red']")));
        methods.waitBySeconds(1);
        Assert.assertTrue(methods.isElementVisible(By.xpath("//div[@class='product-list']//div[@class='product-cr'][8]//i[@class='fa fa-heart red']")));
        methods.waitBySeconds(1);
        methods.click(By.xpath("//img[@title='kitapla buluşmanın en kolay yolu!']"));
        methods.waitBySeconds(1);
        methods.click(By.cssSelector(".menu.top.login"));
        methods.waitBySeconds(2);
        methods.scrollWithAction(By.cssSelector("#content > div.grid_4.omega > div > div:nth-child(2) > ul > li:nth-child(5) > a"));
        methods.waitBySeconds(1);
        methods.click(By.cssSelector("#content > div.grid_4.omega > div > div:nth-child(2) > ul > li:nth-child(5) > a"));
        methods.click(By.cssSelector(".menu.top.my-list")); //Listelerime tıklanır
        methods.waitBySeconds(2);
        methods.click(By.cssSelector("#header-top > div > div.top-menu.fr > ul > li:nth-child(1) > div > ul > li > div > ul > li:nth-child(1) > a")); //Favorilerim kısmına tıklanır
        methods.waitBySeconds(2);
        String value = methods.getText(By.xpath("/html/body/div[5]/div/div[2]/div[1]/div[2]/div/span/span")); //favori sayısı alınır
        System.out.println("Alınan değer: " + value);
        methods.waitBySeconds(2);
        Assert.assertEquals("4", value); // favori sayısı 4 ile karşılaştırılır
        methods.click(By.cssSelector(".logo-text")); //Anasayfaya gider
        methods.waitBySeconds(2);
        methods.click(By.cssSelector(".lvl1catalog")); //puan kataloğu
        methods.waitBySeconds(2);
        methods.click(By.cssSelector("img[title='Puan Kataloğundaki Türk Klasikleri']")); //türk klasikleri
        methods.waitBySeconds(2);
        methods.selectByText(By.cssSelector("div[class='sort']>select[onchange='location = this.value;']"), "Yüksek Oylama"); //Oylama yapar
        methods.waitBySeconds(5);
        methods.click(By.cssSelector("#mainNav > div.nav-content > ul > li.book.has-menu.active > div.lvl2.js-bookCr > ul > li:nth-child(3) > span")); //Tüm kitaplara tıklar
        methods.waitBySeconds(2);
        methods.click(By.cssSelector("li>a[href='kategori/kitap-hobi/1_212.html']")); //Hobilere tıklar
        methods.waitBySeconds(3);
        selectRandomProduct(); //random kitap seçer
        methods.waitBySeconds(3);
        methods.click(By.cssSelector(".add-to-cart.btn-orange.btn-ripple")); //sepete ekler
        methods.waitBySeconds(2);
        methods.click(By.cssSelector(".menu.top.my-list")); //Listelerime tıklanır
        methods.waitBySeconds(2);
        methods.click(By.cssSelector("#header-top > div > div.top-menu.fr > ul > li:nth-child(1) > div > ul > li > div > ul > li:nth-child(1) > a")); //Favorilerim kısmına tıklanır
        methods.waitBySeconds(2);
        methods.click(By.xpath("//div[@class='product-cr'][3]//i[@class='fa fa-heart-o']")); //3.ürünü siler
        methods.waitBySeconds(3);
        methods.click(By.cssSelector("#cart > div.heading")); //sepet açma
        methods.waitBySeconds(3);
        methods.click(By.id("js-cart")); //sepete gitme
        methods.waitBySeconds(2);
        methods.findElement(By.xpath("//input[@name='quantity']")).clear(); //valueyu siler
        methods.waitBySeconds(1);
        methods.sendKeys(By.xpath("//input[@name='quantity']"), "4"); //4 yazdırır
        methods.waitBySeconds(1);
        methods.click(By.xpath("//i[@title='Güncelle']")); //günceller
        methods.waitBySeconds(2);
        methods.click(By.cssSelector("div[class='right']>a[class='button red']")); //satın alma
        methods.waitBySeconds(3);
        //methods.sendKeys(By.id("address-firstname-companyname"),"Merve");
        //methods.waitBySeconds(1);
        //methods.sendKeys(By.id("address-lastname-title"),"Şen");
        //methods.waitBySeconds(1);
        //methods.selectByText(By.cssSelector("#address-zone-id"),"İstanbul" );
        //methods.waitBySeconds(1);
        //methods.selectByText(By.cssSelector("#address-county-id"),"ÜMRANİYE" );
        //methods.waitBySeconds(1);
        //methods.sendKeys(By.id("address-address-text"),"Testinium");
        //methods.waitBySeconds(1);
        //methods.sendKeys(By.id("address-telephone"),"3333333333");
        //methods.waitBySeconds(1);
        //methods.sendKeys(By.id("address-telephone"),"5333333333");
        //methods.waitBySeconds(1);

        methods.click(By.id("button-checkout-continue"));
        methods.waitBySeconds(4);
        methods.click(By.id("button-checkout-continue"));
        methods.waitBySeconds(4);

        methods.sendKeys(By.id("credit-card-owner"), "Merve Şen");
        methods.sendKeys(By.id("credit_card_number_1"), "3333");
        methods.sendKeys(By.id("credit_card_number_2"), "3333");
        methods.sendKeys(By.id("credit_card_number_3"), "3333");
        methods.sendKeys(By.id("credit_card_number_4"), "3333");
        methods.waitBySeconds(2);
        methods.sendKeys(By.id("credit-card-expire-date-month"), "03");
        methods.waitBySeconds(1);
        methods.sendKeys(By.id("credit-card-expire-date-year"), "2025");
        methods.waitBySeconds(1);
        methods.sendKeys(By.id("credit-card-security-code"), "111");
        methods.waitBySeconds(1);
        methods.click(By.id("button-checkout-continue"));
        methods.waitBySeconds(2);
        String errorText = methods.getText(By.cssSelector("#form-credit-card > div.credit-card-form-content > table > tbody > tr:nth-child(5) > td > span"));
        if(errorText!=null){
            System.out.println(errorText);
            methods.click(By.cssSelector("#logo > a > img"));//Homepage
            //Logout
            methods.scrollWithAction1(By.cssSelector("#header-top > div > div.welcome.fl > div.menu.top.login > ul > li > a"));
            methods.clickJS(By.cssSelector("#header-top > div > div.welcome.fl > div.menu.top.login > ul > li > div > ul > li:nth-child(4) > a"));
        } else if (errorText==null){
            System.out.println("Satın alma işlemi gerçekleşiyor.");
        }

    }



    public void selectRandomProduct() {
        List<WebElement> productList = methods.findAllElements(By.cssSelector(".pr-img-link"));
        int randNum = rand.nextInt(productList.size()-1); //0 - productList.size()
        productList.get(randNum).click();
    }


}

