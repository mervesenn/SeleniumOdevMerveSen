package org.example.test;

import org.example.driver.Giris;
import org.example.page.LoginPage;
import org.junit.Test;

public class LoginTest extends Giris {

    @Test
    public void loginTest(){
        LoginPage loginPage = new LoginPage();
        loginPage.login();
    }
}
