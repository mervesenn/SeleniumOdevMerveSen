package org.example.test;

import org.example.driver.Giris;
import org.example.page.LoginPage;
import org.example.page.ProductPage;
import org.junit.Test;

public class ProductTest extends Giris {

    @Test
    public void productTest(){
            LoginPage loginPage = new LoginPage();
            ProductPage productPage = new ProductPage();

            loginPage.login();
            productPage.selectProduct();

    }

}
